<?php

$mod_strings['LBL_UPDATE_QUICKCRM_TITLE'] = "Mise à jour de QuickCRM Mobile";
$mod_strings['LBL_UPDATE_QUICKCRM'] = "Actualisation de QuickCRM Mobile";
$mod_strings['LBL_QUICKCRM'] = 'QuickCRM Mobile';
$mod_strings['LBL_UPDATE_MSG'] = '<strong>Application updated for QuickCRM on mobile</strong><br/>You can access the mobile version at:';
$mod_strings['LBL_ERR_DIR_MSG'] = "Certains fichiers n'ont pu être créés. Vérifiez les droits d'accès pour le dossier : ";


