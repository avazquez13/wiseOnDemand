<?php
$entry_point_registry['QuickCRMgetConfig'] = array(
	'file' => 'custom/QuickCRM/getConfig.php',
	'auth' => false
);
