<?php

$mod_strings['LBL_UPDATE_QUICKCRM_TITLE'] = "QuickCRM Aktualisierung";
$mod_strings['LBL_UPDATE_QUICKCRM'] = "Konfiguration aktualisieren";
$mod_strings['LBL_CONFIG_QUICKCRM_TITLE'] = "Ansichten konfigurieren";
$mod_strings['LBL_CONFIG_QUICKCRM'] = "Definition von Anzeige- und Suchfeldern";
$mod_strings['LBL_QUICKCRM'] = 'QuickCRM Mobile';
$mod_strings['LBL_UPDATE_MSG'] = '<strong>Anwendung für die mobile Nutzung unter QuickCRM aktualisiert</strong><br/>Zugriff auf die mobile Version:';

$mod_strings['LBL_ERR_DIR_MSG'] = 'Einige Dateien konnten nicht erstellt werden. Bitte prüfen Sie die Schreibberechtigungen für: ';


